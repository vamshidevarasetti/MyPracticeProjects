#include <iostream>
#include <compare>
using namespace std;

int main(){
    int a=10, b=20;

    /*auto result = (a <=> b);
    if (result < 0) cout << "a < b\n";
    if (result == 0) cout << "a == b\n";
    if (result > 0) cout << "a > b\n";*/
}

//g++ -std=c++20 spaceship.cpp -o spaceship