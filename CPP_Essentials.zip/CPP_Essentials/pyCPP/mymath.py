# mymath.py (user-defined Python library)
def add(a, b):
    return a + b

def multiply(a, b):
    return a * b
